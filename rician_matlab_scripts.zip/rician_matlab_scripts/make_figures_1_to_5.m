% OCTAVE script to make Figures 1 through 5 for the paper
% "Stochastic Complexity of Rayleigh and Rician Data with
% Normalized Maximum Likelihood"

% Note on my Mac I had to manually copy "gs," the excutable for ghostscript,
% into the Octave binary file path; your mileage may vary

% make rician_b_only_srfim.pdf for Figure 1
% and rician_b_only_int_linear.pdf, rician_b_only_int_log.pdf for Figure 2
clear
fig_rician_b_only

% make rician_ssq_only_gt1.pdf for Figure 3(a)
clear
fig_rician_ssq_only_gt1

% make rician_ssq_only_lt1.pdf for Figure 3(b)
clear
fig_rician_ssq_only_lt1

% make rician_ssq_weird.pdf for Figure 4
clear
fig_rician_ssq_weird

% make rician_sc_linear.pdf and rician_sc_log.pdf for Figure 5
clear
fig_rician_sc
