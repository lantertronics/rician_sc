function output = logstar(n)
if n <= 1,
  output = 0;
else 
  output = 1 + logstar(log2(n));
end