for s = 3:3,
s
as = 0.05:0.05:2^s;
for b=3:3, 
  b
  ssqs=(1/(2^b)):0.01:(2^b);
  detfimr = zeros(length(as),length(ssqs));
  for ai = 1:length(as),
    for ssqi = 1:length(ssqs),
      a = as(ai);
      ssq = ssqs(ssqi);
      rssq = 1/ssq;
      rssq2 = rssq*rssq;    rssq3 = rssq*rssq2;
      rssq4 = rssq*rssq3;   rssq5 = rssq*rssq4;
      %uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq)) ...
      %            .* besseli(1,a*x/ssq).^2 ./ besseli(0,a*x/ssq));
      % Use log form to help with numeric issues
      uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq) ...
             + 2*log(besseli(1,a*x/ssq)) - log(besseli(0,a*x/ssq))));
      u = integral(uintegrand,0,Inf);

      a2 = a*a;
      a3 = a*a2;
      a4 = a*a3;
      fim_a2 = u*rssq3 - a2*rssq2;
      fim_ssq2 = rssq2 - a2*rssq3 - a4*rssq4 + a2*u*rssq5;
      fim_a_ssq = a*rssq2 + a3*rssq3 - a*u*rssq4;
      detfim = fim_a2 * fim_ssq2 - fim_a_ssq^2;
      detfimr(ai,ssqi) = detfim;
    end
  end

  int_over_ssq = 0.01*sum(detfimr,2);
  sc_table(s,b) = log(0.05*sum(int_over_ssq));
end
end
