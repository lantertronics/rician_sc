as = 0.1:0.05:4;
for ssqlimi=1:4, % top ssq integration limits of 2, 4, 6, and 8
  ssqs=(1/(2*ssqlimi)):0.01:(ssqlimi*2);
  for ai = 1:length(as),
    for ssqi = 1:length(ssqs),
      a = as(ai);
      ssq = ssqs(ssqi);
      rssq = 1/ssq;
      rssq2 = rssq*rssq;    rssq3 = rssq*rssq2;
      rssq4 = rssq*rssq3;   rssq5 = rssq*rssq4;
      % uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq)) ...
      %             .* besseli(1,a*x/ssq).^2 ./ besseli(0,a*x/ssq));
      % Use log form to help with numeric issues
      uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq) ...
             + 2*log(besseli(1,a*x/ssq)) - log(besseli(0,a*x/ssq))));
      u = integral(uintegrand,0,Inf);

      a2 = a*a;
      a3 = a*a2;
      a4 = a*a3;
      fim_a2 = u*rssq3 - a2*rssq2;
      fim_ssq2 = rssq2 - a2*rssq3 - a4*rssq4 + a2*u*rssq5;
      fim_a_ssq = a*rssq2 + a3*rssq3 - a*u*rssq4;
      detfim = fim_a2 * fim_ssq2 - fim_a_ssq^2;
      fim_b2r(ai,ssqi) = fim_a2;
      fim_ssq2r(ai,ssqi) = fim_ssq2;
      fim_b_ssqr(ai,ssqi) = fim_a_ssq;
      detfimr(ai,ssqi) = detfim;
      sqrdetfim(ai,ssqi) = sqrt(detfim);
      ur(ai,ssqi) = u;
    end
  end

  int_over_ssq = 0.01*sum(detfimr,2);
  int_to_a(ssqlimi,:) = 0.05*cumsum(int_over_ssq);
end

figure
plot(as,int_to_a);
xlabel('a_{max}', "fontsize", 12)
ylabel('Linear Scale', "fontsize", 12)
title('Integral of sqrt(det(FIM))', "fontsize", 12);
print -dpdfcrop rician_sc_linear.pdf

figure
plot(as,log(int_to_a));
xlabel('a_{max}', "fontsize", 12)
ylabel('Natural Log Scale', "fontsize", 12)
title('Integral of sqrt(det(FIM))', "fontsize", 12);
print -dpdfcrop rician_sc_log.pdf