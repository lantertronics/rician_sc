% OCTAVE script to make Figures 6 for the paper
% "Stochastic Complexity of Rayleigh and Rician Data with
% Normalized Maximum Likelihood"

% You need to first run the experiment30.m script and 
% the experiment100.m script to create the variables
% prob_sc_rice30 and prob_sc_rice100

% Note on my Mac I had to manually copy "gs," the excutable for ghostscript,
% into the Octave binary file path; your mileage may vary

figure
plot(as,100*prob_sc_rice30,':',as,100*prob_sc_rice100,'-');
title('Probability of Correct Decision',"fontsize", 12)
ylabel('Percent',"fontsize", 12)
xlabel('a',"fontsize", 12)
print -dpdfcrop prob_correct.pdf
