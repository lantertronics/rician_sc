as = 0:0.05:8;
ssqs = [1 2 3 4];
for ssqi=1:4, 
  for ai = 1:length(as),
      a = as(ai);
      ssq = ssqs(ssqi);
      rssq = 1/ssq;
      rssq2 = rssq*rssq;    rssq3 = rssq*rssq2;
      % uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq)) ...
      %             .* besseli(1,a*x/ssq).^2 ./ besseli(0,a*x/ssq));
      % Use log form to help with numeric issues
      uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq) ...
             + 2*log(besseli(1,a*x/ssq)) - log(besseli(0,a*x/ssq))));
      u = integral(uintegrand,0,Inf);

      a2 = a*a;
      fim_a2 = u*rssq3 - a2*rssq2;
      sqrfim_a2r(ai,ssqi) = sqrt(fim_a2);
    end
    int_to_a(:,ssqi) = 0.05*cumsum(sqrfim_a2r(:,ssqi));
end

figure
plot(as,sqrfim_a2r);
xlabel('a', "fontsize", 12)
title('sqrt(FIM) for parameter a', "fontsize", 12);
print -dpdfcrop rician_b_only_srfim.pdf

figure
plot(as,int_to_a);
xlabel('a_{max}', "fontsize", 12)
ylabel('Linear Scale', "fontsize", 12)
title('Integral of sqrt(FIM) for parameter a', "fontsize", 12);
print -dpdfcrop rician_b_only_int_linear.pdf

figure
plot(as,log(int_to_a));
xlabel('a_{max}', "fontsize", 12)
ylabel('Natural Log Scale', "fontsize", 12)
title('Integral of sqrt(FIM) for parameter a', "fontsize", 12);
print -dpdfcrop rician_b_only_int_log.pdf