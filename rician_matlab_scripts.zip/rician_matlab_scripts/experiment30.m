rng(42);  % for easy reproducability;
          % different seeds should produce similar plots
numtrials = 200000;
n = 30;

% This is the "sc_table" variable computed by make_sc_table
sc_table =  ...
[-0.8218   1.1247   2.8939;
  0.7067   2.3601   3.9341;
  1.7426   3.2889   4.7841];

c = 2.87;
ssq = 2;
as = 0.05:0.05:2.5;
for ai = 1:length(as),
naive_count = 0;
sc_count = 0;
a = as(ai)
for trial = 1:numtrials,
x = myrician(n,a,ssq);
sqavghalf = sum(x .^ 2) / (2*n);

n = length(x);
ssqhat_ray = sqavghalf;
[ahat, ssqhat_rice] = rician_ml(x,a+0.01,ssq);
b_ray = ceil(log2(max(ssqhat_ray,1/ssqhat_ray)));
b_rice = ceil(log2(max(ssqhat_rice,1/ssqhat_rice)));
s = max(ceil(log2(ahat)),1);

ll_ray = -n*log(ssqhat_ray) - sqavghalf / ssqhat_ray;
ll_rice = -n*log(ssqhat_rice) - sqavghalf / ssqhat_rice ...
          -n*ahat^2/(2*ssqhat_rice) ...
          + sum(log(besseli(0,ahat*x/ssqhat_rice)));

sc_ray = -ll_ray + (1/2)*log(n/(2*pi)) ...
        + log(2*b_ray) + log(log(2)) ...
        + (logstar(b_ray) + c) * log(2);

sc_rice = -ll_rice + (2/2)*log(n/(2*pi)) ...
        + sc_table(s,b_rice) ...
        + (logstar(b_rice) + c) * log(2) ...
        + (logstar(s) + c) * log(2);

if ll_rice > ll_ray, naive_count = naive_count+1; end
if sc_rice < sc_ray, sc_count = sc_count+1; end

end
prob_naive_rice(ai) = naive_count / numtrials;
prob_sc_rice(ai) = sc_count / numtrials;
end
figure

prob_naive_rice30 = prob_naive_rice;
prob_sc_rice30 = prob_sc_rice;
%plot(as,[prob_naive_rice;prob_sc_rice]')
save prob_sc_rice30
