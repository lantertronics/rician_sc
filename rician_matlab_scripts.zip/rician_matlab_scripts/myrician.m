function out = myrician(n,b,ssq);

s = sqrt(ssq);
theta = 2*pi*rand(1,n);
out = sqrt((b*cos(theta) + randn(1,n)*s) .^ 2 + ...
           (b*sin(theta) + randn(1,n)*s) .^ 2);
