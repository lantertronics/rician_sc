%as = [0 1 2 3];
as = [0 0.3 0.6 3];
ssqs = 1:0.01:5;
for ai=1:4, 
  for ssqi = 1:length(ssqs),
      a = as(ai);
      ssq = ssqs(ssqi);
      rssq = 1/ssq;
      rssq2 = rssq*rssq;    rssq3 = rssq*rssq2;
      rssq4 = rssq*rssq3;   rssq5 = rssq*rssq4;
      % uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq)) ...
      %             .* besseli(1,a*x/ssq).^2 ./ besseli(0,a*x/ssq));
      % Use log form to help with numeric issues
      uintegrand = @(x) real(x.^3 .* exp(-(x.^2 + a^2)/(2*ssq) ...
             + 2*log(besseli(1,a*x/ssq)) - log(besseli(0,a*x/ssq))));
      u = integral(uintegrand,0,Inf);

      a2 = a*a;
      a3 = a*a2;
      a4 = a*a3;
      fim_ssq2 = rssq2 - a2*rssq3 - a4*rssq4 + a2*u*rssq5;
      sqrfim_ssq2r(ssqi,ai) = sqrt(fim_ssq2);
    end
end

figure
plot(ssqs,sqrfim_ssq2r(:,1:3));  
hold on
plot(ssqs,sqrfim_ssq2r(:,4),'--'); 
axis tight
xlabel('\sigma^2', "fontsize", 12)
title('sqrt(FIM) for parameter \sigma^2', "fontsize", 12);
print -dpdfcrop rician_ssq_only_gt1.pdf
