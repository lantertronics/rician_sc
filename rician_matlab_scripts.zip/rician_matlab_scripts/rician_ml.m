function [ahat, ssqhat] = rician_ml(x,a,ssq);

ahat = a;
ssqhat = ssq;
n = length(x);
sqavghalf = sum(x .^ 2) / (2*n);
%ahat = mean(x)^2 ./ var(x);
%ssqhat = sqavghalf - ahat^2/2; 
for loop = 1:200,
  thing = ahat * x ./ ssqhat;
  ahat = sum(x .* besseli(1,thing) ./ besseli(0,thing)) / n;
  ssqhat = sqavghalf - ahat^2/2; 
  [ahat ssqhat];
end